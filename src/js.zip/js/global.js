$(function () {
	$.ajax({
	    url: "https://api.flickr.com/services/rest/",
	    data: {
	        method: "flickr.photos.getRecent",
	        api_key: "6dc8742ac1440ba5f52977361096bab4",
	        format: "json",
	        nojsoncallback: 1
	    },
	    success: function (response) {
	        $.each(response.photos.photo, function (index, value) {
	            console.log(value);
	            console.log(value.title);
	            console.log(value.owner);


				var wrapper = $('<section>');
				var photoURL = 'https://farm' + value.farm + '.staticflickr.com/' + value.server + '/' + value.id + '_' + value.secret + '.jpg';
				var a = $('<a>').attr({href: photoURL});
				var img = $('<img>').attr({src: photoURL});
				var owner = 'https://www.flickr.com/photos/' + value.owner;
				var ownerURL = '<a href=' + owner +'>Authors Flickr Page</a>';
				var title = $('<h1>' + value.title + '</h1>');
				var photoDescription;


            	$.ajax({
				    url: "https://api.flickr.com/services/rest/",
				    data: {
				        method: "flickr.photos.getInfo",
				        api_key: "6dc8742ac1440ba5f52977361096bab4",
						photo_id: value.id,
				        format: "json",
				        nojsoncallback: 1
				    },
				    success: function (response2) {
				        $.each(response2.photos.photo, function (index, value) {
				        	photoDescription = value.description;
				        });
				    }
				});



				wrapper.append(a)
				a.append(img);
				wrapper.append(title);
				wrapper.append(ownerURL);
				wrapper.append(photoDescription);
				$("#mygallery").append(wrapper);
	        });
	    }
	});
})